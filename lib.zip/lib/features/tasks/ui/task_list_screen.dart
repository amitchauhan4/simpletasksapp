import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:simpletasksapp/features/tasks/data/task_model.dart';
import '../providers/task_provider.dart';
import 'add_edit_task_screen.dart';

// StateProvider for search query
final searchProvider = StateProvider<String>((ref) => "");

class TaskListScreen extends ConsumerWidget {
  const TaskListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tasks = ref.watch(taskProvider);
    final searchQuery = ref.watch(searchProvider);

    // Filter tasks based on search query (title + details)
    final filteredTasks =
        tasks.where((task) {
          final query = searchQuery.toLowerCase();
          return task.title.toLowerCase().contains(query) ||
              (task.details?.toLowerCase().contains(query) ?? false);
        }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Simple Tasks",
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
      ),

      // Body with search bar + list
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search tasks...",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.grey[200],
              ),
              onChanged: (val) {
                ref.read(searchProvider.notifier).state = val;
              },
            ),
          ),

          // Task list or empty state
          Expanded(
            child:
                filteredTasks.isEmpty
                    ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.task_alt, size: 80, color: Colors.grey),
                          SizedBox(height: 10),
                          Text(
                            "No tasks found",
                            style: TextStyle(fontSize: 20, color: Colors.grey),
                          ),
                        ],
                      ),
                    )
                    : ListView.builder(
                      itemCount: filteredTasks.length,
                      itemBuilder: (context, index) {
                        final task = filteredTasks[index];
                        return Dismissible(
                          key: ValueKey(task.id),
                          onDismissed: (_) {
                            ref
                                .read(taskProvider.notifier)
                                .deleteTask(task.id!);
                          },
                          background: Container(
                            color: Colors.red,
                            alignment: Alignment.centerRight,
                            padding: EdgeInsets.symmetric(horizontal: 20),
                            child: Icon(Icons.delete, color: Colors.white),
                          ),
                          child: Card(
                            margin: EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 3,
                            child: ListTile(
                              contentPadding: EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 8,
                              ),
                              title: Text(
                                task.title,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  decoration:
                                      task.isDone
                                          ? TextDecoration.lineThrough
                                          : null,
                                ),
                              ),
                              subtitle:
                                  task.details != null
                                      ? Text(
                                        task.details!,
                                        style: TextStyle(
                                          fontSize: 14,
                                          decoration:
                                              task.isDone
                                                  ? TextDecoration.lineThrough
                                                  : null,
                                        ),
                                      )
                                      : null,
                              trailing: Checkbox(
                                value: task.isDone,
                                activeColor: Colors.deepPurple,
                                shape: CircleBorder(),
                                onChanged: (val) {
                                  ref
                                      .read(taskProvider.notifier)
                                      .updateTask(
                                        Task(
                                          id: task.id,
                                          title: task.title,
                                          details: task.details,
                                          createdAt: task.createdAt,
                                          updatedAt: DateTime.now(),
                                          isDone: val ?? false,
                                        ),
                                      );
                                },
                              ),
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder:
                                        (_) => AddEditTaskScreen(task: task),
                                  ),
                                );
                              },
                            ),
                          ),
                        );
                      },
                    ),
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => AddEditTaskScreen()),
          );
        },
        backgroundColor: Colors.deepPurple,
        child: Icon(Icons.add_circle_outline, color: Colors.white, size: 28),
      ),
    );
  }
}

import '../data/task_model.dart';
import '../data/task_db.dart';

class TaskRepository {
  final _db = TaskDB.instance;

  Future<List<Task>> getAllTasks() => _db.getTasks();
  Future<int> addTask(Task task) => _db.insertTask(task);
  Future<int> updateTask(Task task) => _db.updateTask(task);
  Future<int> deleteTask(int id) => _db.deleteTask(id);
}

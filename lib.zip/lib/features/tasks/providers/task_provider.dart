import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/task_model.dart';
import '../data/task_repository.dart';

class TaskNotifier extends StateNotifier<List<Task>> {
  final TaskRepository repository;
  TaskNotifier(this.repository) : super([]) {
    loadTasks();
  }

  Future<void> loadTasks() async {
    state = await repository.getAllTasks();
  }

  Future<void> addTask(Task task) async {
    await repository.addTask(task);
    loadTasks();
  }

  Future<void> updateTask(Task task) async {
    await repository.updateTask(task);
    loadTasks();
  }

  Future<void> deleteTask(int id) async {
    await repository.deleteTask(id);
    loadTasks();
  }
}

final taskProvider = StateNotifierProvider<TaskNotifier, List<Task>>((ref) {
  return TaskNotifier(TaskRepository());
});
